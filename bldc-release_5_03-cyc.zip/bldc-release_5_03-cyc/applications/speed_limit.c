#include "ch.h" // ChibiOS
#include "hal.h" // ChibiOS HAL
#include "mc_interface.h" // Motor control functions
#include "hw.h" // Pin mapping on this hardware
#include "timeout.h" // To reset the timeout
#include "app.h" // To reset the timeout
#include "mcpwm_foc.h"
#include "commands.h"
#include "utils.h"

extern volatile float avg_speed_km;

static THD_FUNCTION(speed_limit_thread, arg);
static THD_WORKING_AREA(speed_limit_thread_wa, 2048); // 2kb stack for this thread

void speed_limit_init(void) {

	// Start the thread
	chThdCreateStatic(speed_limit_thread_wa, sizeof(speed_limit_thread_wa),
	NORMALPRIO, speed_limit_thread, NULL);

}

static THD_FUNCTION(speed_limit_thread, arg) { //Speed limit for cadence free running
	(void) arg;

	chRegSetThreadName("Speed Sensor Error Code");
	static int rpm = 0, seconds = 0;

	for (;;) {
		rpm = (int) mc_interface_get_actual_rpm();
		if (rpm > 2000 && avg_speed_km < 5) { //have rpm and still avg speed is 0
			chThdSleepMilliseconds(1000);
			seconds++;
			if (seconds > 10) {
				non_stop_error_register(FAULT_CODE_SPEED_SENSOR);
				seconds = 0;
			}

		} else if (avg_speed_km >= 5) //speed reading is present
			non_stop_error_clear(FAULT_CODE_SPEED_SENSOR);

		chThdSleepMilliseconds(50);

	}
}

