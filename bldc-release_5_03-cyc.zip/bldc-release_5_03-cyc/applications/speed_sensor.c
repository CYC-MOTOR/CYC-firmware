#include "ch.h" // ChibiOS
#include "hal.h" // ChibiOS HAL
#include "mc_interface.h" // Motor control functions
#include "hw.h" // Pin mapping on this hardware
#include "timeout.h" // To reset the timeout
#include "stm32f4xx.h"
#include "stm32f4xx_exti.h"
#include "stm32f4xx_syscfg.h"
#include "misc.h"
#include "stm32f4xx_gpio.c"
#include "stm32f4xx_tim.h"
#include "app.h"
#include "commands.h"
extern chuk_config app_chuk_conf;
extern volatile int frequency_speed;
extern volatile float avg_speed_km;
volatile int speed_time_interval_ms;
volatile float speed_km_h, speed_conversion = 0;
extern volatile uint32_t time_result, time1, time2;
static THD_FUNCTION(speed_sensor_thread, arg);
static THD_WORKING_AREA(speed_sensor_thread_wa, 2048); // 2kb stack for this thread

void Configure_PB5(void) {
	/* Set variables used */
	GPIO_InitTypeDef GPIO_InitStruct;
	EXTI_InitTypeDef EXTI_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;

	/* Enable clock for GPIOB */
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	/* Enable clock for SYSCFG */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

	/* Set pin as input */
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_5;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOB, &GPIO_InitStruct);

	/* Tell system that you will use PB12 for EXTI_Line5 */
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource5);

	/* PB5 is connected to EXTI_Line5 */
	EXTI_InitStruct.EXTI_Line = EXTI_Line5;
	/* Enable interrupt */
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	/* Interrupt mode */
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	/* Triggers on rising and falling edge */
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising;
	/* Add to EXTI */
	EXTI_Init(&EXTI_InitStruct);

	/* Add IRQ vector to NVIC */

	NVIC_InitStruct.NVIC_IRQChannel = EXTI9_5_IRQn;
	/* Set priority */
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	/* Set sub priority */
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0;
	/* Enable interrupt */
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	/* Add to NVIC */
	NVIC_Init(&NVIC_InitStruct);
	nvicEnableVector(EXTI9_5_IRQn, 0);

}

void speed_sensor_init(void) {

	// Start the thread
	chThdCreateStatic(speed_sensor_thread_wa, sizeof(speed_sensor_thread_wa),
	NORMALPRIO, speed_sensor_thread, NULL);
}

float app_get_speed(void) {
	return speed_km_h;
}

static THD_FUNCTION(speed_sensor_thread, arg) {
	(void) arg;

	chRegSetThreadName("APP_SPEED_SENSOR");
	Configure_PB5();
	uint32_t time_now;

	for (;;) {
		//frequency_speed = 0;
		chThdSleepMilliseconds(5);
		time_now = chVTGetSystemTimeX();
		if ((time_now - time1) > 30000) //timeout at 3 seconds
			frequency_speed = 0;
		else if ((time_now - time2) > 30000)
			frequency_speed = 0;

	}
}

