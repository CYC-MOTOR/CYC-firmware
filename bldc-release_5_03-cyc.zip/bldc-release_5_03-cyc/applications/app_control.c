#include "ch.h" // ChibiOS
#include "hal.h" // ChibiOS HAL
#include "mc_interface.h" // Motor control functions
#include "hw.h" // Pin mapping on this hardware
#include "timeout.h" // To reset the timeout
#include "mcpwm_foc.h"
#include "stdio.h"
#include "stdlib.h"
#include "utils.h"
#include "commands.h"

extern volatile float speed_km_h, tick, avg_speed_km;
extern volatile int speed_time_interval_ms, frequency_speed, internal_tick;

extern const uint32_t serial_p;
volatile float speed_limit;
char *product_serial;
volatile float nm;
extern volatile float flag;
extern bool rx;
volatile int once = 0, error_code = 0;
volatile int throttle_error = 0, display_error = 0, speed_sensor_error = 0,
		hall_sensor_error = 0;
extern volatile int mode_display;
volatile int x1pro;

volatile int get_motor_temp;
volatile int get_fet_temp;
volatile float get_rpm;
volatile int get_bbrs;
volatile int get_unit_battery;
extern volatile float speed_km_h;
volatile int display_model = 0;
volatile float torque_sensor_sensitivity = 0;
volatile float torque_adc_baseline = 0;
volatile float cadence_ratio = 0;
volatile float torque_ratio = 0;
volatile float motor_assist_factor = 0;
volatile int display_watt = 0;
volatile float wheel_inch = 0;
volatile int pedal_enable = 0;
volatile int brake_apply;
volatile systime_t start_time;
volatile int race = 0;
char buffer[10];
volatile float throttle_watt_limit;
volatile float pas_watt_limit;
volatile float pas_torque_limit, throttle_torque_limit;

static THD_FUNCTION(example_thread, arg);
static THD_WORKING_AREA(example_thread_wa, 2048); // 2kb stack for this thread

volatile imu_config imu_conf;
volatile balance_config app_balance_conf;
volatile ppm_config app_ppm_conf;
volatile nrf_config app_nrf_conf;
volatile chuk_config app_chuk_conf;
extern volatile pas_config config;

volatile int life_current, sleep_seconds, start_life = 0;

void imu_init(imu_config *set) {
	imu_conf = *set;
}
void app_balance_configure(balance_config *conf) {
	app_balance_conf = *conf;
}
void app_ppm_configure(ppm_config *conf) {
	app_ppm_conf = *conf;
}
void rfhelp_update_conf(nrf_config *conf) {
	app_nrf_conf = *conf;
}
void app_nunchuk_configure(chuk_config *conf) {
	app_chuk_conf = *conf;

}
int get_motor_type(void) {
	return x1pro;
}
//return 0 is off, return 1 is on
int app_get_cadence_start(void) {
	return (int) app_ppm_conf.ctrl_type;
}
//return 0 is off, return 1 is on
int app_get_backwards_cutout(void) {
	return (int) app_ppm_conf.throttle_exp_mode;
}
//return 0 is off, return 1 is on
int app_get_ntc_onoff(void) {
	return app_chuk_conf.ctrl_type;
}

void non_stop_error_clear(int error) {
	if (error == FAULT_CODE_THROTTLE_VOLTAGE)
		throttle_error = 0;
	if (error == FAULT_CODE_HALL_SENSOR)
		hall_sensor_error = 0;
	if (error == FAULT_CODE_SPEED_SENSOR)
		speed_sensor_error = 0;
	if (error == FAULT_CODE_DISPLAY)
		display_error = 0;
}
void non_stop_error_register(int error) {
	if (error == FAULT_CODE_THROTTLE_VOLTAGE)
		throttle_error = 1;
	if (error == FAULT_CODE_HALL_SENSOR)
		hall_sensor_error = 1;
	if (error == FAULT_CODE_SPEED_SENSOR)
		speed_sensor_error = 1;
	if (error == FAULT_CODE_DISPLAY)
		display_error = 1;

}
int app_get_non_stop_error(void) {
	if (throttle_error == 1)
		return FAULT_CODE_THROTTLE_VOLTAGE;
	if (hall_sensor_error == 1)
		return FAULT_CODE_HALL_SENSOR;
	if (speed_sensor_error == 1)
		return FAULT_CODE_SPEED_SENSOR;
	if (display_error == 1)
		return FAULT_CODE_DISPLAY;

	return FAULT_CODE_NONE;
}

void motor_type_switch(void) {
	if (return_motor_type() == BATTERY_TYPE_LIION_3_0__4_2) { //x1pro
		x1pro = 1;
	} else if (return_motor_type() == BATTERY_TYPE_LIIRON_2_6__3_6) { //stealth
		x1pro = 0;
	}
}
float get_gen2_baseline_voltage(void) {

	return app_ppm_conf.ramp_time_pos;
}
void process_speed_limit(float limit) {

	static float result;
	result = avg_speed_km - (float) limit; //real time speed - config limit

	result = utils_map(result, -7, -1, 0, 1); //result input, in min, in max, out min, out max
//reaching -7km start to reduce power, reach -1 same speed cut power
	utils_truncate_number(&result, 0.0, 1);
	speed_limit = 1 - result;
//commands_printf("speed_limit %f", speed_limit);

}

float get_wheel_diameter(void) {
	if (app_nrf_conf.retry_delay == 0) //16
		return 16.0;
	else if (app_nrf_conf.retry_delay == 1)
		return 18;
	else if (app_nrf_conf.retry_delay == 2)
		return 20;
	else if (app_nrf_conf.retry_delay == 3)
		return 22;
	else if (app_nrf_conf.retry_delay == 4)
		return 24;
	else if (app_nrf_conf.retry_delay == 5)
		return 26;
	else if (app_nrf_conf.retry_delay == 6)
		return 27.5;
	else if (app_nrf_conf.retry_delay == 7) //28 or 700c
		return 28;
	else if (app_nrf_conf.retry_delay == 8)
		return 29;

	return 0;

}

void misc_control(void) {

	if (app_nrf_conf.speed == 0) { //display model
		display_model = 0;
	} else if (app_nrf_conf.speed == 1) {
		display_model = 1;
	} else if (app_nrf_conf.speed == 2) {
		display_model = 2;
	}

	wheel_inch = app_balance_conf.tiltback_constant_erpm;

	if (config.ctrl_type) { // Temperature Unit 1, C Temperature
		get_unit_battery |= 1UL << 0;  //set bit 0 C
	} else
		//0, F Temperature
		get_unit_battery &= ~(1UL << 0); //clear bit 0  F

	if (config.invert_pedal_direction) { //Speed Unit 1, miles
		get_unit_battery |= 1UL << 1;  //set bit 1 miles
	} else {
		//0, km
		get_unit_battery &= ~(1UL << 1); //clear bit 1  km
	}
	if (control_get_sw102_ds103_version() == 0) {
		if (app_nrf_conf.retries == 6) //battery cells
				{ //0000xxxx
			get_unit_battery &= ~(1UL << 4); //clear bit
			get_unit_battery &= ~(1UL << 5); //clear bit
			get_unit_battery &= ~(1UL << 6); //clear bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 7) { //0001xxxx

			get_unit_battery |= 1UL << 4;  //set bit
			get_unit_battery &= ~(1UL << 5); //clear bit
			get_unit_battery &= ~(1UL << 6); //clear bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 8) {         //0010xxxx

			get_unit_battery &= ~(1UL << 4); //clear bit
			get_unit_battery |= 1UL << 5;  //set bit
			get_unit_battery &= ~(1UL << 6); //clear bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 9) {  //0011xxxx

			get_unit_battery |= 1UL << 4;  //set bit
			get_unit_battery |= 1UL << 5;  //set bit
			get_unit_battery &= ~(1UL << 6); //clear bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 10) { //0100xxxx

			get_unit_battery &= ~(1UL << 4); //clear bit
			get_unit_battery &= ~(1UL << 5); //clear bit
			get_unit_battery |= 1UL << 6;  //set bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 11) { //0101xxxx
			get_unit_battery |= 1UL << 4;  //set bit
			get_unit_battery &= ~(1UL << 5); //clear bit
			get_unit_battery |= 1UL << 6;  //set bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 12) { //0110xxxx

			get_unit_battery &= ~(1UL << 4); //clear bit
			get_unit_battery |= 1UL << 5;  //set bit
			get_unit_battery |= 1UL << 6;  //set bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 13) { //0111xxxx

			get_unit_battery |= 1UL << 4;  //set bit
			get_unit_battery |= 1UL << 5;  //set bit
			get_unit_battery |= 1UL << 6;  //set bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 14) { //1000xxxx

			get_unit_battery &= ~(1UL << 4); //clear bit
			get_unit_battery &= ~(1UL << 5); //clear bit
			get_unit_battery &= ~(1UL << 6); //clear bit
			get_unit_battery |= 1UL << 7;  //set bit
		}
	} else if (control_get_sw102_ds103_version() == 1) {

		//	commands_printf("v2ok");
		if (app_nrf_conf.retries == 10) //battery cells
				{ //0000xxxx
			get_unit_battery &= ~(1UL << 4); //clear bit
			get_unit_battery &= ~(1UL << 5); //clear bit
			get_unit_battery &= ~(1UL << 6); //clear bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 12) { //0001xxxx

			get_unit_battery |= 1UL << 4;  //set bit
			get_unit_battery &= ~(1UL << 5); //clear bit
			get_unit_battery &= ~(1UL << 6); //clear bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 13) {         //0010xxxx

			get_unit_battery &= ~(1UL << 4); //clear bit
			get_unit_battery |= 1UL << 5;  //set bit
			get_unit_battery &= ~(1UL << 6); //clear bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 14) {  //0011xxxx

			get_unit_battery |= 1UL << 4;  //set bit
			get_unit_battery |= 1UL << 5;  //set bit
			get_unit_battery &= ~(1UL << 6); //clear bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 15) { //0100xxxx

			get_unit_battery &= ~(1UL << 4); //clear bit
			get_unit_battery &= ~(1UL << 5); //clear bit
			get_unit_battery |= 1UL << 6;  //set bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 16) { //0101xxxx
			get_unit_battery |= 1UL << 4;  //set bit
			get_unit_battery &= ~(1UL << 5); //clear bit
			get_unit_battery |= 1UL << 6;  //set bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 17) { //0110xxxx

			get_unit_battery &= ~(1UL << 4); //clear bit
			get_unit_battery |= 1UL << 5;  //set bit
			get_unit_battery |= 1UL << 6;  //set bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 18) { //0111xxxx

			get_unit_battery |= 1UL << 4;  //set bit
			get_unit_battery |= 1UL << 5;  //set bit
			get_unit_battery |= 1UL << 6;  //set bit
			get_unit_battery &= ~(1UL << 7); //clear bit

		} else if (app_nrf_conf.retries == 20) { //1000xxxx

			get_unit_battery &= ~(1UL << 4); //clear bit
			get_unit_battery &= ~(1UL << 5); //clear bit
			get_unit_battery &= ~(1UL << 6); //clear bit
			get_unit_battery |= 1UL << 7;  //set bit
		}
	}
//display settings lock
	if (app_ppm_conf.median_filter == 0) { //no display settings lock
		get_bbrs |= 1UL << 4;
		get_bbrs &= ~(1UL << 5); //set bit 45 as 10
	} else if (app_ppm_conf.median_filter == 1) { //hv display settings lock
		get_bbrs |= 1UL << 4;
		get_bbrs |= 1UL << 5; //set bit 45 as 11
	}
/*
	if (rx == 1) {
		get_bbrs |= 1UL << 6; //set bit 6 as 1 bluetooth
	} else
		get_bbrs &= ~(1UL << 6);*/
//mode after reboot
	if (app_nrf_conf.power == 0) { //mode before reboot
		get_bbrs |= 1UL << 2;
		get_bbrs |= 1UL << 3; //set bit 23 as 11
	} else if (app_nrf_conf.power == 1) { //set to street after reboot
		get_bbrs |= 1UL << 2;
		get_bbrs &= ~(1UL << 3); //set bit 23 as 10
		if (once == 0) {
			once = 1;
			if (chVTTimeElapsedSinceX(start_time) < 30000) //3 seconds
					{
				rs_handler(0); //set to street
			}
		}

	} else if (app_nrf_conf.power == 2) { //set to race after reboot
		get_bbrs &= ~(1UL << 2);
		get_bbrs &= ~(1UL << 3); //set bit 23 as 00
		if (once == 0) {
			once = 1;
			if (chVTTimeElapsedSinceX(start_time) < 30000) //3 seconds
					{
				rs_handler(1); //set to race
			}
		}
	}

	if (config.sensor_type) { //race street mode switch
		get_bbrs |= 1UL << 1; //set bit1=1 race
	} else {
		get_bbrs &= ~(1UL << 1); //clear bit1=0 street
	}
}

void pedal_assist_control(void) {

	if (app_balance_conf.multi_esc) {  //pedal assist enable
		pedal_enable = 1;

	} else
		pedal_enable = 0;

}

void brake_sensor_control(void) {

	if (app_nrf_conf.send_crc_ack) {	//brake sensor enable

		if (!palReadPad(GPIOB, 12)) {

			if (app_adc_get_brake_invert() == 0) {
				brake_apply = 0;	//brake applied
				get_bbrs |= 1UL << 7;  //set bbrs bit 7 brake sensor on
			} else {
				brake_apply = 1;
				get_bbrs &= ~(1UL << 7); //clear bbrs bit 7 brake sensor off
			}
		} else {
			if (app_adc_get_brake_invert() == 0) {
				brake_apply = 1;
				get_bbrs &= ~(1UL << 7); //clear bbrs bit 7 brake sensor off
			} else {
				brake_apply = 0;	//brake applied
				get_bbrs |= 1UL << 7;  //set bbrs bit 7 brake sensor on
			}

		}
	} else { //brake sensor disable
		brake_apply = 1;
		get_bbrs &= ~(1UL << 7); //clear bbrs bit 7 brake sensor off
	}

}
void serial_no_generation(void) {

	char serial[25];
	char *p = serial_p;	//(uint32_t*) serial_p
	for (int i = 0; i < 21; i++) {	//serial no.
		serial[i] = *(p + i);
	}
	product_serial = (char*) malloc(1 + strlen(serial) + strlen(HW_NAME));
	strcpy(product_serial, HW_NAME);
	strcat(product_serial, serial);
}
void wattage_torque_speed_mode_control(void) {
	if (mode_display) {	//1 is race mode
		process_speed_limit(app_ppm_conf.pulse_end);
		if (flag == 0.2) {         //1/5, 1/9

			throttle_watt_limit = (app_chuk_conf.ramp_time_pos) * 0.33;
			pas_watt_limit = (app_chuk_conf.stick_erpm_per_s_in_cc) * 0.33;
			pas_torque_limit = app_chuk_conf.hyst * 0.33;
			throttle_torque_limit = app_chuk_conf.ramp_time_neg * 0.33;

		} else if (flag == 0.3) {  //2/9 only
			throttle_watt_limit = (app_chuk_conf.ramp_time_pos) * 0.66;
			pas_watt_limit = (app_chuk_conf.stick_erpm_per_s_in_cc) * 0.66;
			pas_torque_limit = app_chuk_conf.hyst * 0.66;
			throttle_torque_limit = app_chuk_conf.ramp_time_neg * 0.66;

		} else if (flag == 0.4) {    //1/3, 2/5, 3/9
			throttle_watt_limit = app_chuk_conf.ramp_time_pos;     //1
			pas_watt_limit = (app_chuk_conf.stick_erpm_per_s_in_cc);

			pas_torque_limit = app_chuk_conf.hyst;
			throttle_torque_limit = app_chuk_conf.ramp_time_neg;

		} else if (flag == 0.5) {     //4/9 only
			throttle_watt_limit = ((app_chuk_conf.smart_rev_max_duty
					+ app_chuk_conf.ramp_time_pos) / 3) * 1.25;
			pas_watt_limit = ((app_balance_conf.roll_steer_kp
					+ app_chuk_conf.stick_erpm_per_s_in_cc) / 3) * 1.25;
			pas_torque_limit = ((app_balance_conf.brake_current
					+ app_chuk_conf.hyst) / 3) * 1.25;
			throttle_torque_limit = ((app_chuk_conf.smart_rev_ramp_time
					+ app_chuk_conf.ramp_time_neg) / 3) * 1.25;

		} else if (flag == 0.6) {     //3/5, 5/9
			throttle_watt_limit = ((app_chuk_conf.smart_rev_max_duty
					+ app_chuk_conf.ramp_time_pos) / 3) * 1.5;
			pas_watt_limit = ((app_balance_conf.roll_steer_kp
					+ app_chuk_conf.stick_erpm_per_s_in_cc) / 3) * 1.5;
			pas_torque_limit = ((app_balance_conf.brake_current
					+ app_chuk_conf.hyst) / 3) * 1.5;
			throttle_torque_limit = ((app_chuk_conf.smart_rev_ramp_time
					+ app_chuk_conf.ramp_time_neg) / 3) * 1.5;

		} else if (flag == 0.7) {     //2/3, 6/9
			throttle_watt_limit = app_chuk_conf.smart_rev_max_duty;  //2
			pas_watt_limit = (app_balance_conf.roll_steer_kp);
			pas_torque_limit = app_balance_conf.brake_current;
			throttle_torque_limit = app_chuk_conf.smart_rev_ramp_time;

		} else if (flag == 0.8) {  //4/5, 7/9
			throttle_watt_limit = ((app_balance_conf.roll_steer_erpm_kp
					+ app_chuk_conf.smart_rev_max_duty) / 3) * 1.25;
			pas_watt_limit = ((app_ppm_conf.ramp_time_neg
					+ app_balance_conf.roll_steer_kp) / 3) * 1.25;
			pas_torque_limit = ((app_ppm_conf.max_erpm_for_dir
					+ app_balance_conf.brake_current) / 3) * 1.25;
			throttle_torque_limit = ((app_balance_conf.yaw_current_clamp
					+ app_chuk_conf.smart_rev_ramp_time) / 3) * 1.25;

		} else if (flag == 0.9) {  //8/9 only
			throttle_watt_limit = ((app_balance_conf.roll_steer_erpm_kp
					+ app_chuk_conf.smart_rev_max_duty) / 3) * 1.5;
			pas_watt_limit = ((app_ppm_conf.ramp_time_neg
					+ app_balance_conf.roll_steer_kp) / 3) * 1.5;
			pas_torque_limit = ((app_ppm_conf.max_erpm_for_dir
					+ app_balance_conf.brake_current) / 3) * 1.5;
			throttle_torque_limit = ((app_balance_conf.yaw_current_clamp
					+ app_chuk_conf.smart_rev_ramp_time) / 3) * 1.5;

		} else if (flag == 1) { //  3/3, 5/5, 9/9
			throttle_watt_limit = app_balance_conf.roll_steer_erpm_kp; //3
			pas_watt_limit = (app_ppm_conf.ramp_time_neg);
			pas_torque_limit = app_ppm_conf.max_erpm_for_dir;
			throttle_torque_limit = app_balance_conf.yaw_current_clamp;

		} else if (flag == 2) { //race testing
			throttle_watt_limit = 5000; //3
			pas_watt_limit = 5000;
			pas_torque_limit = 100;
			throttle_torque_limit = 100;

		}

		else { //0xf  //did not connect display for some reason
			   //brake_apply = 0;

		}
	} else   //Street
	{
		process_speed_limit(app_ppm_conf.pulse_start);
		if (flag == 0.2) {

			throttle_watt_limit = (imu_conf.accel_confidence_decay) * 0.33;
			pas_watt_limit = (imu_conf.mahony_ki) * 0.33;
			pas_torque_limit = imu_conf.madgwick_beta * 0.33;
			throttle_torque_limit = imu_conf.mahony_kp * 0.33;

		} else if (flag == 0.3) {

			throttle_watt_limit = (imu_conf.accel_confidence_decay) * 0.66;
			pas_watt_limit = (imu_conf.mahony_ki) * 0.66;
			pas_torque_limit = imu_conf.madgwick_beta * 0.66;
			throttle_torque_limit = imu_conf.mahony_kp * 0.66;

		} else if (flag == 0.4) {					//1

			throttle_watt_limit = imu_conf.accel_confidence_decay;
			pas_watt_limit = imu_conf.mahony_ki;
			pas_torque_limit = imu_conf.madgwick_beta;
			throttle_torque_limit = imu_conf.mahony_kp;

		} else if (flag == 0.5) {

			throttle_watt_limit = ((imu_conf.rot_roll
					+ imu_conf.accel_confidence_decay) / 3) * 1.25;
			pas_watt_limit = ((imu_conf.rot_yaw + imu_conf.mahony_ki) / 3)
					* 1.25;
			pas_torque_limit = ((imu_conf.accel_offsets[0]
					+ imu_conf.madgwick_beta) / 3) * 1.25;
			throttle_torque_limit = ((imu_conf.rot_pitch + imu_conf.mahony_kp)
					/ 3) * 1.25;

		} else if (flag == 0.6) {

			throttle_watt_limit = ((imu_conf.rot_roll
					+ imu_conf.accel_confidence_decay) / 3) * 1.5;
			pas_watt_limit = ((imu_conf.rot_yaw + imu_conf.mahony_ki) / 3)
					* 1.5;
			pas_torque_limit = ((imu_conf.accel_offsets[0]
					+ imu_conf.madgwick_beta) / 3) * 1.5;
			throttle_torque_limit = ((imu_conf.rot_pitch + imu_conf.mahony_kp)
					/ 3) * 1.5;

		} else if (flag == 0.7) {

			throttle_watt_limit = imu_conf.rot_roll;   //2
			pas_watt_limit = imu_conf.rot_yaw;
			pas_torque_limit = imu_conf.accel_offsets[0];
			throttle_torque_limit = imu_conf.rot_pitch;

		} else if (flag == 0.8) {

			throttle_watt_limit =
					((app_ppm_conf.tc_max_diff + imu_conf.rot_roll) / 3) * 1.25;
			pas_watt_limit =
					((app_ppm_conf.throttle_exp + imu_conf.rot_yaw) / 3) * 1.25;
			pas_torque_limit = ((app_ppm_conf.throttle_exp_brake
					+ imu_conf.accel_offsets[0]) / 3) * 1.25;
			throttle_torque_limit = ((app_ppm_conf.hyst + imu_conf.rot_pitch)
					/ 3) * 1.25;

		} else if (flag == 0.9) {

			throttle_watt_limit =
					((app_ppm_conf.tc_max_diff + imu_conf.rot_roll) / 3) * 1.5;
			pas_watt_limit =
					((app_ppm_conf.throttle_exp + imu_conf.rot_yaw) / 3) * 1.5;
			pas_torque_limit = ((app_ppm_conf.throttle_exp_brake
					+ imu_conf.accel_offsets[0]) / 3) * 1.5;
			throttle_torque_limit = ((app_ppm_conf.hyst + imu_conf.rot_pitch)
					/ 3) * 1.5;

		} else if (flag == 1) {

			throttle_watt_limit = app_ppm_conf.tc_max_diff;   //3
			pas_watt_limit = app_ppm_conf.throttle_exp;
			pas_torque_limit = app_ppm_conf.throttle_exp_brake;
			throttle_torque_limit = app_ppm_conf.hyst;

		} else {  //0xf //did not connect display for some reason
			//brake_apply = 0;

		}
	}
}

void five_v_protection(void) {   //5v short circuit protection
	if (palReadPad(GPIOC, 14) == 0) {

		palClearPad(GPIOC, 15);
		palWritePad(GPIOC, 15, 0);
	}

}

void io_setup(void) {
	palSetPadMode(GPIOB, 12, PAL_MODE_INPUT_PULLUP);  //Brake Sensor
	palSetPadMode(GPIOC, 14, PAL_MODE_INPUT); //5V high/low detection
	palSetPadMode(GPIOC, 15, PAL_MODE_OUTPUT_PUSHPULL); //5V EN pin, must pp
	palSetPad(GPIOC, 15);   //turn on 5V

}

void speed_sensor(void) {
	static float rpm, ms2s, ms = 0;

	speed_time_interval_ms = (frequency_speed / 10) * app_chuk_conf.tc_max_diff; //relution time times wheel magnet
	ms = speed_time_interval_ms;
	ms2s = ms / (float) 1000;
	rpm = (float) 60 / (float) ms2s;

	/*
	 Let us calculate the rpm to kmh of the car; the 250 mm diameter of the tire is rotating at 980 revolution per minute.
	 Speed of the car in kMH = 0.1885 * 980 * 0.25 = 43.2 kmph.
	 * */
//diameter is inches, 1 inches=2.54cm, convert to diameter
	speed_km_h = (float) 0.1885 * rpm
			* ((get_wheel_diameter() * (float) 2.54) / (float) 100);
	if (speed_km_h > 150) //inf
		speed_km_h = 0;

}

void cadence_sensor(void) {
	static float rpm, ms2s, ms, result = 0;

	result = (internal_tick / 10) * 32; //64 pulses 1 revolution time
	ms = result;
	ms2s = ms / (float) 1000;
	rpm = (float) 60 / (float) ms2s;
	if (rpm > 500) //infinity
		tick = 0;
	else
		tick = (int) rpm;
}

void app_control_init(void) {

// Start the example thread
	chThdCreateStatic(example_thread_wa, sizeof(example_thread_wa),
	NORMALPRIO, example_thread, NULL);
}

static THD_FUNCTION(example_thread, arg) {
	(void) arg;
	start_time = chVTGetSystemTimeX();
	chRegSetThreadName("APP_Control");
	io_setup();
	hall_sensor_error_check_once();
	serial_no_generation();   //generate serial no.
	update_phase_cal();   // update phase current calibration
	if (TESTING_WITHOUT_DISPLAY) {
		throttle_watt_limit = 1500000;
		pas_watt_limit = 1500000;
		pas_torque_limit = 100;   //%
		throttle_torque_limit = 100;
		brake_apply = 1;
		speed_limit = 1;

	}

	for (;;) {

		if (!TESTING_WITHOUT_DISPLAY) {

			wattage_torque_speed_mode_control();
			brake_sensor_control();
			pedal_assist_control();
			speed_sensor();
			cadence_sensor();
			misc_control();
			motor_type_switch();
		}
		five_v_protection();
		systime_t sleep_time = CH_CFG_ST_FREQUENCY / 300;
		// At least one tick should be slept to not block the other threads
		if (sleep_time == 0) {
			sleep_time = 1;
		}
		/*
		 static volatile int tmp = 0;
		 tmp = palReadPad(GPIOC, 6);	//HALL1
		 tmp = tmp | (palReadPad(GPIOC, 7) << 1);	//HALL2
		 tmp = tmp | (palReadPad(GPIOC, 8) << 2);	//HALL3
		 tmp = tmp | (palReadPad(GPIOB, 5) << 3);	//Speed
		 tmp = tmp | (palReadPad(GPIOB, 12) << 4);	//Brake for OQC
		 tmp = tmp | (palReadPad(GPIOC, 13) << 5);	//Cad
		 tmp = tmp | (!palReadPad(GPIOB, 12) << 6);	//Brake For app//B-12
		 tmp = tmp | (palReadPad(GPIOB, 7) << 7);	//Digital torque IO
		 tmp = tmp | (palReadPad(GPIOA, 6) << 8);	//Analog torque IO

		 commands_printf("IO: %i", tmp);
		 */
		chThdSleep(sleep_time);
		timeout_reset();
	}
}

