#include "ch.h" // ChibiOS
#include "hal.h" // ChibiOS HAL
#include "mc_interface.h" // Motor control functions
#include "hw.h" // Pin mapping on this hardware
#include "timeout.h" // To reset the timeout
#include "stm32f4xx.h"
#include "stm32f4xx_exti.h"
#include "stm32f4xx_syscfg.h"
#include "misc.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_tim.h"
#include "utils.h"
#include "app.h"
#include <math.h>
extern volatile uint32_t big_nm;
extern volatile float nm, tick, speed_conversion, speed_km_h;
extern volatile int pedal_direction, speed_time_interval_ms;

volatile int digital_torque_sensor = 0;
volatile float filtered_torque_out, rt_torque, avg_cadence, avg_speed_km,
		avg_voltage, cadence_timeout;

static THD_FUNCTION(torque_sensor_3_thread, arg);
static THD_WORKING_AREA(torque_sensor_3_thread_wa, 2048); // 2kb stack for this thread

void torque_sensor_3_init(void) {

	// Start the thread
	chThdCreateStatic(torque_sensor_3_thread_wa,
			sizeof(torque_sensor_3_thread_wa),
			NORMALPRIO, torque_sensor_3_thread, NULL);
}

static THD_FUNCTION(torque_sensor_3_thread, arg) {
	(void) arg;

	chRegSetThreadName("Torque Voltage Digital Filtering");

	float local_torque = 0;

	for (;;) {
		rt_torque = big_nm / (float) 10000;
		if ((VSBM) && digital_torque_sensor == 0) { //analog torque sensor
			static float adc_read;
			adc_read = (float) ADC_Value[ADC_IND_EXT2];
			adc_read /= 4095;
			adc_read *= V_REG;
			rt_torque = adc_read;
			pedal_direction = 0xf1; //disable pedal direction
		}

		if (tick == 0) //0 rpm
			cadence_timeout = get_sample_time() - 1;
		else
			cadence_timeout = 0;

		if (pedal_direction == 0xf0) //backward pedal
			cadence_timeout = get_sample_time() - 1;
		else
			cadence_timeout = 0;

		if (digital_torque_sensor) {
			UTILS_LP_MOVING_AVG_APPROX(local_torque, rt_torque,
					get_sample_time() - cadence_timeout); //local_torque to other, real time, sampling rate
		} else {
			UTILS_LP_MOVING_AVG_APPROX(local_torque, rt_torque,
					get_sample_time() * 3 - cadence_timeout * 3); //local_torque to other, real time, sampling rate
		}

		if (digital_torque_sensor) {
			filtered_torque_out = local_torque;
			nm = local_torque;
		} else {
			filtered_torque_out = local_torque; //let main output thread handle adc, local_torque still analog voltage
			nm = utils_map(local_torque, get_gen2_baseline_voltage(), 3.3, 0,
					102.9); // map adc voltage to NM.
			if (nm < 0)
				nm = 0; //below baseline voltage
		}
		timeout_reset();

		UTILS_LP_MOVING_AVG_APPROX(avg_speed_km, speed_km_h, 500);
		UTILS_LP_MOVING_AVG_APPROX(avg_voltage, GET_INPUT_VOLTAGE(), 500);
		UTILS_LP_MOVING_AVG_APPROX(avg_cadence, tick, 200);
		chThdSleepMilliseconds(4);

	}
}

