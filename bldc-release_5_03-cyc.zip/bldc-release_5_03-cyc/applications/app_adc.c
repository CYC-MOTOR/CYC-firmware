#include "app.h"

#include "ch.h"
#include "hal.h"
#include "stm32f4xx_conf.h"
#include "mc_interface.h"
#include "timeout.h"
#include "utils.h"
#include "comm_can.h"
#include "hw.h"
#include <math.h>

#include <string.h>

extern volatile float pas_torque_limit, throttle_torque_limit,
		throttle_watt_limit, speed_limit;
volatile float flag = 99;
volatile float torque = 0;
volatile float speedo = 0;
volatile float throttle_power_monitor = 0;
extern volatile float walk_current;
extern volatile float torque_output;

extern volatile int brake_apply, oqc;

// Settings
#define MAX_CAN_AGE						0.1
#define MIN_MS_WITHOUT_POWER			500
#define FILTER_SAMPLES					10
#define RPM_FILTER_SAMPLES				8

// Threads
static THD_FUNCTION(adc_thread, arg);
static THD_WORKING_AREA(adc_thread_wa, 1024);

// Private variables
static volatile adc_config config;
static volatile float ms_without_power = 0.0;
static volatile float decoded_level = 0.0;
static volatile float read_voltage = 0.0;
static volatile float decoded_level2 = 0.0;
static volatile float read_voltage2 = 0.0;
//static volatile bool use_rx_tx_as_buttons = false;
static volatile bool stop_now = true;
static volatile bool is_running = false;

void app_adc_configure(adc_config *conf) {
	config = *conf;
	ms_without_power = 0.0;
}

void app_adc_start(bool use_rx_tx) {

//	use_rx_tx_as_buttons = use_rx_tx;
	stop_now = false;
	chThdCreateStatic(adc_thread_wa, sizeof(adc_thread_wa), NORMALPRIO,
			adc_thread, NULL);
}

void app_adc_stop(void) {
	stop_now = true;
	while (is_running) {
		chThdSleepMilliseconds(1);
	}
}

float app_adc_get_decoded_level(void) {
	return decoded_level;
}

float app_adc_get_voltage(void) {
	return read_voltage;
}

float app_adc_get_decoded_level2(void) {
	return decoded_level2;
}

float app_adc_get_voltage2(void) {
	return read_voltage2;
}

int app_adc_get_brake_invert(void) {
	return (int) config.rev_button_inverted;
}

static THD_FUNCTION(adc_thread, arg) {
	(void) arg;

	chRegSetThreadName("APP_ADC_Main Output");
	is_running = true;
	char buffer[20];
	int brake_pressed = 0;
	float pwr = 0;
	float brake = 0;
	for (;;) {

		pwr = (float) ADC_Value[ADC_IND_EXT];
		pwr /= 4095;
		pwr *= 5.55;		//assume all are 2k 3k

		read_voltage = pwr;

		brake = (float) ADC_Value[9];
		brake /= 4095;
		brake *= 5.55;

		read_voltage2 = brake;
		brake = 0;		//turn off regen for now

		// Sleep for a time according to the specified rate
		systime_t sleep_time = CH_CFG_ST_FREQUENCY / 600;
		// At least one tick should be slept to not block the other threads
		if (sleep_time == 0) {
			sleep_time = 1;
		}
		chThdSleep(sleep_time);

		if (stop_now) {
			is_running = false;
			return;
		}

		// For safe start when fault codes occur
		if (mc_interface_get_fault() != FAULT_CODE_NONE) {
			ms_without_power = 0;
		}
		if (config.ctrl_type) { //any of the type
			if (pwr > config.voltage_end + 0.5
					|| read_voltage <= (config.voltage_start - 0.5)) {
				non_stop_error_register(FAULT_CODE_THROTTLE_VOLTAGE);
				pwr = 0;
			} else
				non_stop_error_clear(FAULT_CODE_THROTTLE_VOLTAGE);
		} else if (config.ctrl_type == 0)
			non_stop_error_clear(FAULT_CODE_THROTTLE_VOLTAGE);

		pwr = utils_map(pwr, config.voltage_start, config.voltage_end, 0.0,
				1.0);
		// Truncate the read voltage
		utils_truncate_number(&pwr, 0.0, 1.0);

		decoded_level = pwr;

		brake = utils_map(brake, config.voltage2_start, config.voltage2_end,
				0.0, 1.0);
		utils_truncate_number(&brake, 0.0, 1.0);
		decoded_level2 = brake;

		// All pins and buttons are still decoded for debugging, even
		// when output is disabled.
		if (app_is_output_disabled()) {
			continue;
		}
		// Apply deadband
		utils_deadband(&pwr, config.hyst, 1.0);
		//	utils_deadband(&brake, config.hyst, 1.0);
		// Apply throttle curve
		pwr = utils_throttle_curve(pwr, config.throttle_exp,
				config.throttle_exp_brake, config.throttle_exp_mode);

		brake = utils_throttle_curve(brake, config.throttle_exp,
				config.throttle_exp_brake, config.throttle_exp_mode);

		switch (config.ctrl_type) {
		case ADC_CTRL_TYPE_CURRENT_NOREV_BRAKE_ADC:
		case ADC_CTRL_TYPE_CURRENT_REV_BUTTON_BRAKE_ADC:
			//pwr -= brake;
			break;
		default:
			break;

		}

		utils_deadband(&pwr, config.hyst, 1.0);
		// Apply ramping
		static systime_t last_time = 0;
		static float pwr_ramp = 0.0;
		float ramp_time =
				fabsf(pwr) > fabsf(pwr_ramp) ?
						config.ramp_time_pos : config.ramp_time_neg;
		if (ramp_time > 0.01) {
			const float ramp_step = (float) ST2MS(
					chVTTimeElapsedSinceX(last_time)) / (ramp_time * 1000.0);
			utils_step_towards(&pwr_ramp, pwr, ramp_step);
			last_time = chVTGetSystemTimeX();
			pwr = pwr_ramp;
		}

		bool current_mode_brake = false;
		bool current_mode_reverse = false;

		float current_rel = 0.0;
		switch (config.ctrl_type) {
		case ADC_CTRL_TYPE_CURRENT:
			current_rel = pwr;
			if (fabsf(pwr) < 0.001) {
				ms_without_power += (1000.0 * (float) sleep_time)
						/ (float) CH_CFG_ST_FREQUENCY;
			}
			break;

		}

		timeout_reset();
		float current_out = current_rel;

		if (walk_current > 0)
			set_motor_rpm_limit(5000);
		else
			set_motor_rpm_limit(100000);

		if (!TESTING_WITHOUT_DISPLAY) {	// Normal running mode//!TESTING_WITHOUT_DISPLAY
			if (flag == 0xF) {	//display gear 0
				mc_interface_set_current_rel(0);

			} else if (oqc != 1) {

				switch (config.ctrl_type) {
				case ADC_CTRL_TYPE_NONE:
					mc_interface_set_current_rel(
							((torque_output * (pas_torque_limit / (float) 100))
									+ walk_current) * brake_apply
									* speed_limit);
					break;
				case ADC_CTRL_TYPE_CURRENT:

					if (current_out > 0) {
						set_motor_watt_limit(throttle_watt_limit);
					} else if (current_out < 0)
						current_out = 0;

					mc_interface_set_current_rel(
							((current_out
									* (throttle_torque_limit / (float) 100))
									+ (torque_output
											* (pas_torque_limit / (float) 100))
									+ walk_current) * brake_apply
									* speed_limit);

					break;

				}

			}

		}

	}
}

