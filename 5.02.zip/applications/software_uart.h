#define OI_TXD	PCout(13)
#define OI_RXD	PBin(14)

#define BuadRate_9600	100

volatile uint8_t len = 0;
volatile uint8_t USART_buf[12];

enum {
	COM_START_BIT,
	COM_D0_BIT,
	COM_D1_BIT,
	COM_D2_BIT,
	COM_D3_BIT,
	COM_D4_BIT,
	COM_D5_BIT,
	COM_D6_BIT,
	COM_D7_BIT,
	COM_STOP_BIT,
};

volatile uint8_t recvStat = COM_STOP_BIT;
volatile uint8_t recvData = 0;
