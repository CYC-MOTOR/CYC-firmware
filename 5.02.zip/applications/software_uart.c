#include "ch.h" // ChibiOS
#include "hal.h" // ChibiOS HAL
#include "mc_interface.h" // Motor control functions
#include "hw.h" // Pin mapping on this hardware
#include "timeout.h" // To reset the timeout
#include "stm32f4xx.h"
#include "stm32f4xx_exti.h"
#include "stm32f4xx_syscfg.h"
#include "misc.h"
#include "stm32f4xx_tim.h"
#include "stm32f4xx_gpio.h"
#include "app.h"

#include "conf_general.h"
#include "hw.h"

//#include "softuart.h"
#include <string.h>
#define BAUDRATE					9600
static SerialConfig uart_cfg = { BAUDRATE, 0,
USART_CR2_LINEN, 0 };

extern volatile int pedal_direction, digital_torque_sensor;
extern volatile uint32_t big_nm;
static int direction, data1, data2, data3, crc_h, crc_l, crc_check;
void IOConfig(void) {
	GPIO_InitTypeDef GPIO_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	EXTI_InitTypeDef EXTI_InitStruct;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	/* Enable clock for SYSCFG */
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	//SoftWare Serial RXD
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;

	GPIO_Init(GPIOA, &GPIO_InitStructure);

	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource6);

	EXTI_InitStruct.EXTI_Line = EXTI_Line6;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling; //下降沿触发中断
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStruct);

	NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	nvicEnableVector(EXTI9_5_IRQn, 6);
}

void TIM3_Int_Init(uint16_t arr, uint16_t psc) {
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); //时钟使能

	//定时器TIM3初始化
	TIM_TimeBaseStructure.TIM_Period = arr; //设置在下一个更新事件装入活动的自动重装载寄存器周期的值
	TIM_TimeBaseStructure.TIM_Prescaler = psc; //设置用来作为TIMx时钟频率除数的预分频值
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; //设置时钟分割:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //TIM向上计数模式
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); //根据指定的参数初始化TIMx的时间基数单位
	TIM_ClearITPendingBit(TIM3, TIM_FLAG_Update);
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE); //使能指定的TIM3中断,允许更新中断

	//中断优先级NVIC设置
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;  //TIM3中断
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;  //先占优先级1级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;  //从优先级1级
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //IRQ通道被使能
	NVIC_Init(&NVIC_InitStructure);  //初始化NVIC寄存器
}

static THD_FUNCTION(software_uart_thread, arg);
static THD_WORKING_AREA(software_uart_thread_wa, 2048); // 2kb stack for this thread

void software_uart_init(void) {

	// Start the thread
	chThdCreateStatic(software_uart_thread_wa, sizeof(software_uart_thread_wa),
	NORMALPRIO, software_uart_thread, NULL);
}

void software_uart_port_start(void) {
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//设置中断优先级分组为组2：2位抢占优先级，2位响应优先级
	TIM3_Int_Init(107, 83);	//arr,psc //1M计数频率//xx107,,71+1
	IOConfig();
}

void hardware_uart_port_start(void) {	//PB7
	sdStart(&SD1, &uart_cfg);
	palSetPadMode(GPIOB, 7,
			PAL_MODE_ALTERNATE(GPIO_AF_USART1) | PAL_STM32_OSPEED_HIGHEST | PAL_STM32_PUDR_PULLDOWN);
	/*
	 event_listener_t elt;
	 chEvtRegisterMaskWithFlags(&SD1.event, &elt, EVENT_MASK(0),
	 CHN_INPUT_AVAILABLE);*/
}

void hardware_uart_get_data(void) {
	//chEvtWaitAnyTimeout(ALL_EVENTS, ST2MS(10));

	direction = sdGet(&SD1);

	/*while ((direction != 0xF0) || (direction != 0xF1)) {
	 direction = sdGet(&SD1);
	 }*/
	if (direction == 0xF0 || direction == 0xF1) {	//0xf0 is reverse
		data1 = sdGet(&SD1);
		data2 = sdGet(&SD1);
		data3 = sdGet(&SD1);
		crc_h = sdGet(&SD1);
		crc_l = sdGet(&SD1);

		crc_check = direction + data1 + data2 + data3 + 2;
		if ((crc_check >> 8) == crc_h && (crc_check & 0xFF) == crc_l) {
			pedal_direction = direction;
			big_nm = (data1 << 16) | data2 << 8 | data3;
			digital_torque_sensor = 1;

			//commands_printf("crc ok");

		} else {
			big_nm = 0;
			//commands_printf("crc failed");
		}
	} else {	//wrong data
		big_nm = 0;
		//commands_printf("data failed");
	}
}

static THD_FUNCTION(software_uart_thread, arg) {
	(void) arg;

	chRegSetThreadName("Software/Hardware Uart");

//////////////////////////////
	if (PHOTON_240) {
		software_uart_port_start();	//Legacy batch photon support
	}
	if (VSBM || VPRO_181) {	//start legacy analog adc torque sensor support on all conversion kit
		palSetPadMode(GPIOA, 6, PAL_MODE_INPUT_ANALOG);
	}
	hardware_uart_port_start();	//start on all devices
//////////////////////////////

	for (;;) {

		//	chEvtWaitAnyTimeout(ALL_EVENTS, ST2MS(10));
		hardware_uart_get_data();
		//timeout_reset();
	}
}

