#include "ch.h" // ChibiOS
#include "hal.h" // ChibiOS HAL
#include "mc_interface.h" // Motor control functions
#include "hw.h" // Pin mapping on this hardware
#include "timeout.h" // To reset the timeout
#include "stm32f4xx.h"
#include "stm32f4xx_exti.h"
#include "stm32f4xx_syscfg.h"
#include "misc.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_tim.h"
#include "commands.h"

extern volatile int internal_tick, tick_fast; //for irq thread
extern volatile uint32_t time1_tick, time2_tick, time_result_tick;
volatile float tick; //for adc thread
static THD_FUNCTION(torque_sensor_thread, arg);
static THD_WORKING_AREA(torque_sensor_thread_wa, 2048); // 2kb stack for this thread

void Configure_PC13(void) {
	/* Set variables used */
	GPIO_InitTypeDef GPIO_InitStruct;
	EXTI_InitTypeDef EXTI_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;

	/* Enable clock for GPIOB */
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
	/* Enable clock for SYSCFG */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

	/* Set pin as input */
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOC, &GPIO_InitStruct);

	/* Tell system that you will use PC13 for EXTI_Line13 */
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOC, EXTI_PinSource13);

	/* PB5 is connected to EXTI_Line13 */
	EXTI_InitStruct.EXTI_Line = EXTI_Line13;
	/* Enable interrupt */
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	/* Interrupt mode */
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	/* Triggers on rising and falling edge */
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	/* Add to EXTI */
	EXTI_Init(&EXTI_InitStruct);

	/* Add IRQ vector to NVIC */
	/* PC13 is connected to EXTI_Line13, which has EXTI15_10_IRQn vector */

	NVIC_InitStruct.NVIC_IRQChannel = EXTI15_10_IRQn;
	/* Set priority */
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x00;
	/* Set sub priority */
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0x00;
	/* Enable interrupt */
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	/* Add to NVIC */
	NVIC_Init(&NVIC_InitStruct);
	nvicEnableVector(EXTI15_10_IRQn, 0);

}

void torque_sensor_init(void) {

	// Start the thread
	chThdCreateStatic(torque_sensor_thread_wa, sizeof(torque_sensor_thread_wa),
	NORMALPRIO, torque_sensor_thread, NULL);
}

static THD_FUNCTION(torque_sensor_thread, arg) {
	(void) arg;

	chRegSetThreadName("Cadence Tick");
	Configure_PC13();
	char buffer[5];
	uint32_t time_now;
	for (;;) {

		time_now = chVTGetSystemTimeX();
		if ((time_now - time1_tick) > 5000) //timeout at 500 miliseconds
				{
			tick_fast = 0;
			internal_tick = 0;
		}

		chThdSleepMilliseconds(1);

	}
}

