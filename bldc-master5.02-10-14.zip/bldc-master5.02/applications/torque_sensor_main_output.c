#include "ch.h" // ChibiOS
#include "hal.h" // ChibiOS HAL
#include "mc_interface.h" // Motor control functions
#include "hw.h" // Pin mapping on this hardware
#include "timeout.h" // To reset the timeout
#include "stm32f4xx.h"
#include "stm32f4xx_exti.h"
#include "stm32f4xx_syscfg.h"
#include "misc.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_tim.h"
#include "utils.h"
#include "app.h"
#include "stm32f4xx_conf.h"
#include "commands.h"
#include <string.h>
#include <math.h>

#include "mempools.h"
extern balance_config app_balance_conf;
extern volatile float pas_watt_limit, tick, filtered_torque_out, nm, rt_torque;
extern volatile int pedal_enable, pedal_direction, digital_torque_sensor,
		tick_fast;
//extern volatile uint32_t big_nm;
volatile float torque_speedo, baseline_voltage, torque_output, pas_test,
		pas_test2;

static THD_FUNCTION(torque_sensor_2_thread, arg);
static THD_WORKING_AREA(torque_sensor_2_thread_wa, 2048); // 2kb stack for this thread

void torque_sensor_2_init(void) {
	// Start the thread
	chThdCreateStatic(torque_sensor_2_thread_wa,
			sizeof(torque_sensor_2_thread_wa),
			NORMALPRIO, torque_sensor_2_thread, NULL);
}

int get_sample_time(void) {
	return (app_balance_conf.startup_roll_tolerance * 2) + 1;
}

static THD_FUNCTION(torque_sensor_2_thread, arg) {
	(void) arg;

	chRegSetThreadName("Torque Output");
	float output = 0;

	int cadence_start = 1, backwards_cutout = 1;
	float power = 0;

	for (;;) {

		if (pedal_enable) {
			// Sleep for a time according to the specified rate
			systime_t sleep_time = CH_CFG_ST_FREQUENCY / 300;
			// At least one tick should be slept to not block the other threads
			if (sleep_time == 0) {
				sleep_time = 1;
			}
			chThdSleep(sleep_time);

			cadence_start = app_get_cadence_start();
			backwards_cutout = app_get_backwards_cutout();
			//////commands_printf("cadence_start %i backwards_cutout%i",
			//	cadence_start, backwards_cutout);
			if (cadence_start == 0) { //no cadence start, static engage
				if (digital_torque_sensor)
					power = filtered_torque_out;
				else if (tick == 0) //analog torque sensor can't have static start
					power = 0;
			} else { //cadence_start
				if (tick > 0 || tick_fast > 0)
					power = filtered_torque_out;
				else
					//cadence rpm=0
					power = 0;
			}

			if (digital_torque_sensor && backwards_cutout) {
				if (pedal_direction == 0xf0 && rt_torque < 6)
					//staying at backward and rt torque at idle level
					power = 0;
				else
					//staying at backward and pedal, allow power when rt >50
					power = filtered_torque_out;
			}

			output = power; //capture torque

			if (digital_torque_sensor) {
				static float digital_map;
				static float sensitivity;
				sensitivity = app_balance_conf.startup_pitch_tolerance / 10;
				//sensitivity mapping
				if (sensitivity >= 0 && sensitivity < 1)
					digital_map = utils_map(sensitivity, 0, 1, 5.5, 5);
				else if (sensitivity >= 1 && sensitivity < 2)
					digital_map = utils_map(sensitivity, 1, 2, 5, 4.5);
				else if (sensitivity >= 2 && sensitivity < 3)
					digital_map = utils_map(sensitivity, 2, 3, 4.5, 4);
				else if (sensitivity >= 3 && sensitivity < 4)
					digital_map = utils_map(sensitivity, 3, 4, 4, 3.5);
				else if (sensitivity >= 4 && sensitivity < 5)
					digital_map = utils_map(sensitivity, 4, 5, 3.5, 3);
				else if (sensitivity >= 5 && sensitivity < 6)
					digital_map = utils_map(sensitivity, 5, 6, 3, 2.5);
				else if (sensitivity >= 6 && sensitivity < 7)
					digital_map = utils_map(sensitivity, 6, 7, 2.5, 2);
				else if (sensitivity >= 7 && sensitivity < 8)
					digital_map = utils_map(sensitivity, 7, 8, 2, 1.9);
				else if (sensitivity >= 8 && sensitivity < 9)
					digital_map = utils_map(sensitivity, 8, 9, 1.9, 1.8);
				else if (sensitivity >= 9 && sensitivity <= 10)
					digital_map = utils_map(sensitivity, 9, 10, 1.8, 1.7);

				//	commands_printf("sensitivity %.3f", digital_map);

				/*		digital_map = utils_map(
				 (float) 1
				 - (app_balance_conf.startup_pitch_tolerance
				 / (float) 100), 0, 1, 2, 25);*/
				//motor assist factor
				output = utils_map(output, digital_map,
						175 - (app_balance_conf.tiltback_low_voltage * 1.2), 0,
						1);

			} else { //analog torque sensor
				static float analog_torque_start_map, analog_torque_end_map;
				static float analog_sensitivity;
				analog_sensitivity = app_balance_conf.startup_pitch_tolerance
						/ 10;

				analog_sensitivity = utils_map(analog_sensitivity, 0, 10, 1.65,
						1.45);
				//	commands_printf("sensitivity %.3f", analog_sensitivity);

				/*
				 analog_torque_start_map = 1.55
				 + ((90 - app_balance_conf.startup_pitch_tolerance)
				 / (float) 90);*/
				//hardcode 1.5v analog baseline voltage, map app sensitivity 0-100%
				analog_torque_end_map = 3.0
						- (app_balance_conf.tiltback_low_voltage / (float) 90);
				//hardcode 3.0v analog max voltage output, map motor assist factor to output

				output = utils_map(output, analog_sensitivity,
						analog_torque_end_map, 0, 1);

			}
			// Truncate the read nm
			utils_truncate_number(&output, 0.0, 1.0);
			output = utils_throttle_curve(output, 3, 0, 0); //torque output, positive curve, negative curve, curve mode (2 is poly))

			if (output > 0) {
				set_motor_watt_limit(pas_watt_limit);
				torque_output = output;
			} else
				// <=0 output have negative
				torque_output = 0;

		} else {
			timeout_reset();
			chThdSleepMilliseconds(500);
		}
	}
}

